package com.itsgmobility.hrbenefits.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class UBAutoCompleteLayout extends ConstraintLayout {

    private AppCompatTextView tvTitle;
    private UBAutoCompleteTextView ubAutoCompleteTextView;
    private AppCompatTextView tvError;
    private ProgressBar progressBar;

    private Drawable mDrawableLeft;
    private Drawable mDrawableTop;
    private Drawable mDrawableRight;
    private Drawable mDrawableBottom;

    public UBAutoCompleteLayout(Context context) {
        super(context);
    }

    public UBAutoCompleteLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public UBAutoCompleteLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        inflate(getContext(), R.layout.ub_autocomplete_layout, this);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.UBAutoCompleteLayout);

        try {
            String title = a.getString(R.styleable.UBAutoCompleteLayout_headerTitle);
            String errorText = a.getString(R.styleable.UBAutoCompleteLayout_errorText);

            tvTitle = findViewById(R.id.tv_title);
            ubAutoCompleteTextView = findViewById(R.id.ub_autocomplete_textview);
            tvError = findViewById(R.id.tv_error_text);
            progressBar = findViewById(R.id.progress_circular);

            initTitle(title);
            initErrorText(errorText);

            mDrawableLeft = ubAutoCompleteTextView.getCompoundDrawables()[0];
            mDrawableTop = ubAutoCompleteTextView.getCompoundDrawables()[1];
            mDrawableRight = ubAutoCompleteTextView.getCompoundDrawables()[2];
            mDrawableBottom = ubAutoCompleteTextView.getCompoundDrawables()[3];

        } finally {
            a.recycle();
        }
    }

    private void initTitle(String title) {
        /* set text */
        tvTitle.setText(title);

        /* set visibility */
        setTitleVisibility(title);
    }

    private void initErrorText(String errorText) {
        /* set text */
        tvError.setText(errorText);

        /* set visibility */
        setErrorTextVisibility(errorText);
    }

    public void setTitle(String title) {
        tvTitle.setText(title);

        setTitleVisibility(title);
    }

    public String getTitle() {
        return tvTitle.getText().toString();
    }

    public void setTitle(int titleResource) {
        tvTitle.setText(titleResource);

        setTitleVisibility(getContext().getString(titleResource));
    }

    public String getErrorText() {
        return tvError.getText().toString();
    }

    public void setErrorText(String errorText) {
        tvError.setText(errorText);

        setErrorTextVisibility(errorText);
    }

    public UBAutoCompleteTextView getEditText() {
        return ubAutoCompleteTextView;
    }

    private void setTitleVisibility(String title) {
        tvTitle.setVisibility(title != null && !title.isEmpty() ? VISIBLE : GONE);
    }

    private void setErrorTextVisibility(String errorText) {
        tvError.setVisibility(errorText != null && !errorText.isEmpty() ? VISIBLE : GONE);
    }

    public void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? VISIBLE : GONE);

        if (loading) {
            ubAutoCompleteTextView.setCompoundDrawablesWithIntrinsicBounds(mDrawableLeft, mDrawableTop, null, mDrawableBottom);
        } else {
            ubAutoCompleteTextView.setCompoundDrawablesWithIntrinsicBounds(mDrawableLeft, mDrawableTop, mDrawableRight, mDrawableBottom);
        }
    }
}
