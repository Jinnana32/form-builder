package com.itsgmobility.hrbenefits.ui

import android.support.v4.app.Fragment

class LoaderFragment : Fragment() {



}