package com.itsgmobility.hrbenefits.ui

import android.content.Context
import android.support.v7.widget.AppCompatEditText
import android.util.AttributeSet

class UBSearchEditText : AppCompatEditText {

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs, R.attr.ubSearchEditTextStyle)
}