package com.itsgmobility.hrbenefits.ui;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.util.AttributeSet;

public class UBListView extends ConstraintLayout {

    public UBListView(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.listButtonStyle);
    }
}
