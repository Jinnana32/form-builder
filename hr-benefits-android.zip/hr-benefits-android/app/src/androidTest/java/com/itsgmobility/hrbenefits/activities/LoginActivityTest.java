package com.itsgmobility.hrbenefits.activities;

import android.support.test.espresso.intent.Intents;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.itsgmobility.hrbenefits.ui.generic.fingerprint.FingerPrintFragment;
import com.itsgmobility.hrbenefits.ui.generic.login.LoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;

@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {

    @Rule
    public ActivityTestRule mActivityRule =
            new ActivityTestRule<>(LoginActivity.class);

    @Test
    public void shouldProceedBiometrics() {
        Intents.init();

        ((LoginActivity) mActivityRule.getActivity()).showBiometrics("", "");
        intended(hasComponent(FingerPrintFragment.class.getName()));
    }
}
