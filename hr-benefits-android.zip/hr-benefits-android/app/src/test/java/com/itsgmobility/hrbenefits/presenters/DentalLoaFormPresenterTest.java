package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.BranchItem;
import com.itsgmobility.hrbenefits.common.item.DependentItem;
import com.itsgmobility.hrbenefits.common.item.ProcedureItem;
import com.itsgmobility.hrbenefits.domain.interactor.dentalloa.SubmitDentalLoaInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.medical.dentalloaissuance.DentalLoaFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.dentalloaissuance.DentalLoaFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsNot.not;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class DentalLoaFormPresenterTest extends PresenterTest {

    @InjectMocks
    DentalLoaFormPresenter mPresenter;

    @Mock
    VisitModuleInteractor mVisitModuleInteractor;

    @Mock
    SubmitDentalLoaInteractor mSubmitDentalLoaInteractor;

    @Mock
    DentalLoaFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void submitFormForReview_validateRequiredFields() {
        mPresenter.submitFormReview();

        verify(mView).setRecipientStatus(any(Validation.class));
        verify(mView).setBranchStatus(any(Validation.class));
        verify(mView).setScheduleStatus(any(Validation.class));
        verify(mView).setProcedureStatus(any(Validation.class));

        verify(mView, never()).disableForm();
    }

    @Test
    public void submitFormForReview_showFormReview() {
        mPresenter.setDependent(mock(DependentItem.class));
        mPresenter.setBranch(mock(BranchItem.class));
        mPresenter.setSchedule(Calendar.getInstance(), "testdate");

        List<ProcedureItem> mockProcedureItems = new ArrayList<>();
        mockProcedureItems.add(mock(ProcedureItem.class));

        mPresenter.getChosenProcedures().addAll(mockProcedureItems);

        mPresenter.submitFormReview();

        verify(mView).disableForm();
    }

    private static DependentItem getMockChosenDependent() {
        List<ProcedureItem> mockProcedures = new ArrayList<>();

        mockProcedures.add(ProcedureItem.builder()
                .id(2)
                .limit(0)
                .amount(0)
                .name("test1")
                .build());

        mockProcedures.add(ProcedureItem.builder()
                .id(3)
                .limit(0)
                .amount(0)
                .name("test2")
                .build());

        mockProcedures.add(ProcedureItem.builder()
                .id(4)
                .limit(0)
                .amount(0)
                .name("test3")
                .build());

        mockProcedures.add(ProcedureItem.builder()
                .id(5)
                .limit(0)
                .amount(0)
                .name("test4")
                .build());

        mockProcedures.add(ProcedureItem.builder()
                .id(6)
                .limit(0)
                .amount(0)
                .name("test5")
                .build());

        return DependentItem.builder()
                .id(0)
                .procedures(mockProcedures)
                .limit(0)
                .build();
    }

    @Test
    public void shouldShowBranchDialog() {
        List<BranchItem> mockBranchItems = new ArrayList<>();

        mockBranchItems.add(BranchItem.create(0, "test1"));
        mockBranchItems.add(BranchItem.create(1, "test2"));

        mPresenter.showBranchDialog(mockBranchItems, "error");

        verify(mView).showBranchDialog(new String[]{"test1", "test2"});
    }

    @Test
    public void shouldShowProceduresDialog() {
        mPresenter.setDependent(getMockChosenDependent());
        mPresenter.getChosenProcedures().addAll(getMockChosenProcedures());

        mPresenter.showProceduresDialog("error");

        verify(mView).showProceduresDialog(
                new String[]{"test1", "test2", "test3", "test4", "test5"},
                new boolean[]{true, false, false, false, false});
    }

    @Test
    public void shouldAddUnlimitedProcedures() {
        mPresenter.setDependent(getMockChosenDependent());
        mPresenter.getChosenProcedures().addAll(getMockChosenProcedures());

        mPresenter.updateChosenProcedures(new boolean[]{true, true}); // add the 2nd procedure of dependent (which is an unlimited procedure)

        List<ProcedureItem> resultProcedureItems = getMockChosenProcedures();

        resultProcedureItems.add(getMockChosenDependent().procedures().get(1));

        assertThat(mPresenter.getChosenProcedures(), equalTo(resultProcedureItems));
    }

    @Test
    public void shouldNotAddExistingProcedures() {
        mPresenter.setDependent(getMockChosenDependent());
        mPresenter.getChosenProcedures().addAll(getMockChosenProcedures());

        mPresenter.updateChosenProcedures(new boolean[]{true}); // add the 1st procedure of dependent (which is not an unlimited procedure)

        List<ProcedureItem> resultProcedureItems = getMockChosenProcedures();

        assertThat(getMockChosenProcedures(), equalTo(resultProcedureItems));

        resultProcedureItems.add(getMockChosenDependent().procedures().get(0));

        assertThat(getMockChosenProcedures(), not(equalTo(resultProcedureItems)));
    }

    /**
     * Test unlimited procedures should not be marked,
     * for unlimited procedures, please refer to {@link DentalLoaFormPresenter.UNLIMITED_PROCEDURES}
     */
    @Test
    public void getSelectedProcedures_shouldNotReturnUnlimitedProcedures() {
        mPresenter.setDependent(getMockChosenDependent());
        mPresenter.getChosenProcedures().addAll(getMockChosenProcedures());

        mPresenter.getSelectedProcedures()
                .test()
                .assertValue(arr -> Arrays.equals(arr, new boolean[]{true, false, false, false, false}));
    }

    @Test
    public void shouldShowRecipientDialog() {
        List<DependentItem> mockDependentItems = new ArrayList<>();

        mockDependentItems.add(DependentItem.builder()
                .id(0)
                .name("test1")
                .limit(0)
                .build());

        mockDependentItems.add(DependentItem.builder()
                .id(1)
                .name("test2")
                .limit(0)
                .build());

        mPresenter.showRecipientDialog(mockDependentItems, "error");

        verify(mView).showRecipientDialog(new String[]{"test1", "test2"});
    }

    private static List<ProcedureItem> getMockChosenProcedures() {
        List<ProcedureItem> mockChosenProcedures = new ArrayList<>();

        mockChosenProcedures.add(ProcedureItem.builder()
                .id(2)
                .limit(0)
                .amount(0)
                .name("test1")
                .build());

        mockChosenProcedures.add(ProcedureItem.builder()
                .id(3)
                .limit(0)
                .amount(0)
                .name("test2")
                .build());

        mockChosenProcedures.add(ProcedureItem.builder()
                .id(4)
                .limit(0)
                .amount(0)
                .name("test3")
                .build());

        mockChosenProcedures.add(ProcedureItem.builder()
                .id(5)
                .limit(0)
                .amount(0)
                .name("test4")
                .build());

        mockChosenProcedures.add(ProcedureItem.builder()
                .id(6)
                .limit(0)
                .amount(0)
                .name("test5")
                .build());

        return mockChosenProcedures;
    }
}
