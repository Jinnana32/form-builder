package com.itsgmobility.hrbenefits.presenters

import com.itsgmobility.hrbenefits.domain.interactor.learningpathway.GetAssessmentDetailsInteractor
import com.itsgmobility.hrbenefits.domain.interactor.learningpathway.GetAssessmentQuestionsInteractor
import com.itsgmobility.hrbenefits.domain.interactor.learningpathway.GetLearningPathwayCommentsInteractor
import com.itsgmobility.hrbenefits.domain.interactor.learningpathway.GetResourcesInteractor
import com.itsgmobility.hrbenefits.ui.learning.learningpathway.learningplanvideo.LearningPlanVideoMvpView
import com.itsgmobility.hrbenefits.ui.learning.learningpathway.learningplanvideo.LearningPlanVideoPresenter
import org.junit.Before
import org.mockito.Mock

class LearningPlanVideoPresenterTest : PresenterTest() {

    @Mock
    lateinit var mGetAssessmentDetailsInteractor : GetAssessmentDetailsInteractor

    @Mock
    lateinit var mGetAssessmentQuestionsInteractor : GetAssessmentQuestionsInteractor

    @Mock
    lateinit var mGetCommentsInteractor : GetLearningPathwayCommentsInteractor

    @Mock
    lateinit var mGetResourcesInteractor : GetResourcesInteractor

    @Mock
    lateinit var mPresenter: LearningPlanVideoPresenter

    @Mock
    lateinit var mvpView: LearningPlanVideoMvpView

    @Before
    fun setup(){ mPresenter.attachView(mvpView) }



}