package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.form.FormAgreementInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.form.SubmitBenefitFeedbackInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.generic.formagree.FormAgreeMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.generic.formagree.FormAgreePresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class FormAgreePresenterTest extends PresenterTest {

    @InjectMocks
    FormAgreePresenter mPresenter;

    @Mock
    FormAgreeMvpView mView;

    @Mock
    FormAgreementInteractor formAgreementInteractor;

    @Mock
    SubmitBenefitFeedbackInteractor submitBenefitFeedbackInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldShowExceedMessage() {
        mPresenter.setMessageStatus("has message");

        verify(mView).showExceedMessage("has message");
    }

    @Test
    public void shouldNotShowExceedMessage() {
        mPresenter.setMessageStatus("");

        verify(mView, never()).showExceedMessage("");
    }
}
