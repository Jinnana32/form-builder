package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.OnBoardingSkillsItem;
import com.itsgmobility.hrbenefits.domain.interactor.preemp.GetSkillLevelInteractor;
import com.itsgmobility.hrbenefits.domain.model.SkillLevel;
import com.itsgmobility.hrbenefits.ui.preemp.activity.skills.OnBoardingSkillsFormMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.activity.skills.OnBoardingSkillsFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class OnBoardingSkillsPresenterTest extends PresenterTest {

    @InjectMocks
    OnBoardingSkillsFormPresenter mPresenter;

    @Mock
    OnBoardingSkillsFormMvpView mView;

    @Mock
    GetSkillLevelInteractor mSkillLevelInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldValidate() {
        mPresenter.submitForm();

        verify(mView).setSkillLevelStatus(any(Validation.class));
        verify(mView).setSkillStatus(any(Validation.class));
        verify(mView, never()).submitForm(any(OnBoardingSkillsItem.class));
    }

    @Test
    public void shouldSubmit() {
        List<SkillLevel> mockSkillLevels = new ArrayList<>();

        mockSkillLevels.add(SkillLevel.builder()
                .id(1)
                .skill("test")
                .build());

        mockSkillLevels.add(SkillLevel.builder()
                .id(2)
                .skill("test2")
                .build());

        given(mSkillLevelInteractor.execute()).willReturn(Single.just(mockSkillLevels));

        mPresenter.getSkillLevel();
        mPresenter.setSkillLevel(0);
        mPresenter.setSkill("test");

        mPresenter.submitForm();

        verify(mView).submitForm(any(OnBoardingSkillsItem.class));
    }
}
