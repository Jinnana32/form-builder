package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.DependentItem;
import com.itsgmobility.hrbenefits.common.item.VaccineAvailmentItem;
import com.itsgmobility.hrbenefits.common.item.VaccineItem;
import com.itsgmobility.hrbenefits.ui.benefits.vaccine.vaccineform.VaccineFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.vaccine.vaccineform.VaccineFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class VaccineFormPresenterTest extends PresenterTest {

    @InjectMocks
    VaccineFormPresenter mPresenter;

    @Mock
    VaccineFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldNotSubmit() {
        mPresenter.buildVaccineAvailment();

        verify(mView).setSelectedRecipientStatus(any(Validation.class));
        verify(mView).setAvailmentTypeStatus(any(Validation.class));
        verify(mView).setVaccineStatus(any(Validation.class));

        verify(mView, never()).buildVaccineAvailmentItem(any(VaccineAvailmentItem.class));
    }

    @Test
    public void shouldSubmit() {
        List<DependentItem> dependentItemList = new ArrayList<>();
        dependentItemList.add(DependentItem.builder()
                .id(0)
                .name("test")
                .limit(0)
                .build());

        mPresenter.setDependentItems(dependentItemList);

        List<VaccineItem> vaccineItems = new ArrayList<>();
        vaccineItems.add(VaccineItem.builder()
                .id(0)
                .cost(0)
                .availmentLimit(0)
                .build());
        mPresenter.setVaccineItems(vaccineItems);

        mPresenter.setSelectedRecipient(0);
        mPresenter.setAvailmentType(0);
        mPresenter.updateChosenVaccine(new boolean[]{true});

        mPresenter.buildVaccineAvailment();

        verify(mView).buildVaccineAvailmentItem(any(VaccineAvailmentItem.class));
    }
}
