package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.educreimbursement.SubmitEducReimbursementPersonalInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.educational.personal.EducationPersonalFormPresenter;
import com.itsgmobility.hrbenefits.ui.benefits.educational.personal.EducationPersonalMvpView;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.Calendar;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

public class EducationPersonalFormPresenterTest extends PresenterTest {

    @InjectMocks
    EducationPersonalFormPresenter mPresenter;

    @Mock
    EducationPersonalMvpView mView;

    @Mock
    VisitModuleInteractor visitModuleInteractor;

    @Mock
    SubmitEducReimbursementPersonalInteractor mSubmitEducReimbursementPersonalInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void validYear() {
        assertTrue(mPresenter.isValidAcademicYear("1234"));
    }

    @Test
    public void inValidYear() {
        Assert.assertFalse(mPresenter.isValidAcademicYear("12.12"));
        Assert.assertFalse(mPresenter.isValidAcademicYear("12.1"));
        Assert.assertFalse(mPresenter.isValidAcademicYear("abcd"));
    }

    @Test
    public void shouldNotShowPreviousYear() {
        int presentYear = Calendar.getInstance().get(Calendar.YEAR);

        mPresenter.showFromAcademicYearDialog();
        mPresenter.setSelectedFromYear(2); // set next year as selected
        verify(mView).showFromYear(String.valueOf(presentYear));

        mPresenter.showToAcademicYearDialog();
        verify(mView).showAcademicYearDialog(new String[]{String.valueOf(presentYear)}, -1);
    }

    @Test
    public void shouldNotShowFromFutureYear() {
        int pastPastYear = Calendar.getInstance().get(Calendar.YEAR) - 2;
        int pastYear = Calendar.getInstance().get(Calendar.YEAR) - 1;
        int presentYear = Calendar.getInstance().get(Calendar.YEAR);

        mPresenter.showFromAcademicYearDialog();
        verify(mView).showAcademicYearDialog(new String[]{String.valueOf(pastPastYear), String.valueOf(pastYear), String.valueOf(presentYear)}, -1);

        mPresenter.setSelectedToYear(2);
        mPresenter.showFromAcademicYearDialog();
        verify(mView, atLeastOnce()).showAcademicYearDialog(new String[]{String.valueOf(pastPastYear), String.valueOf(pastYear), String.valueOf(presentYear)}, -1);
    }
}
