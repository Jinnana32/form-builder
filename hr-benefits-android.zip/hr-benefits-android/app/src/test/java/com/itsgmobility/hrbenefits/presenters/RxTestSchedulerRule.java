package com.itsgmobility.hrbenefits.presenters;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import io.reactivex.Scheduler;
import io.reactivex.android.plugins.RxAndroidPlugins;
import io.reactivex.internal.schedulers.ExecutorScheduler;
import io.reactivex.plugins.RxJavaPlugins;
import io.reactivex.schedulers.TestScheduler;

public class RxTestSchedulerRule implements TestRule {

    private final TestScheduler mTestScheduler = new TestScheduler();
    private final Scheduler mImmediateScheduler = new Scheduler() {
        @Override
        public Worker createWorker() {
            return new ExecutorScheduler.ExecutorWorker(Runnable::run);
        }
    };

    public TestScheduler getTestScheduler() {
        return mTestScheduler;
    }

    public Scheduler getImmediateScheduler() {
        return mImmediateScheduler;
    }

    @Override
    public Statement apply(final Statement base, Description description) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                RxJavaPlugins.setIoSchedulerHandler(scheduler -> mImmediateScheduler);
                RxJavaPlugins.setNewThreadSchedulerHandler(scheduler -> mImmediateScheduler);
                RxJavaPlugins.setComputationSchedulerHandler(scheduler -> mImmediateScheduler);
                RxAndroidPlugins.setMainThreadSchedulerHandler(scheduler -> mImmediateScheduler);
                RxAndroidPlugins.setInitMainThreadSchedulerHandler(scheduler -> mImmediateScheduler);

                try {
                    base.evaluate();
                } finally {
                    RxJavaPlugins.reset();
                    RxAndroidPlugins.reset();
                }
            }
        };
    }
}
