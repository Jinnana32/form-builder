package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.preemp.GetPreEmpUploadedDocumentInteractor;
import com.itsgmobility.hrbenefits.domain.model.PreEmpDocument;
import com.itsgmobility.hrbenefits.domain.model.PreEmpUploadedDocument;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.preemppersonnelsignature.PreEmpPersonnelSignatureMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.preemppersonnelsignature.PreEmpPersonnelSignaturePresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;

import io.reactivex.Observable;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

public class PreEmpPersonnelSignatureFragmentPresenterTest extends PresenterTest {

    @InjectMocks
    PreEmpPersonnelSignaturePresenter mPresenter;

    @Mock
    PreEmpPersonnelSignatureMvpView mView;

    @Mock
    GetPreEmpUploadedDocumentInteractor mGetPreEmpUploadedDocumentInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldDisplayDocumentStatus() {
        PreEmpUploadedDocument mockPreEmpUploadedDocument = PreEmpUploadedDocument.builder()
                .urls(new ArrayList<>())
                .documentId(PreEmpDocument.PERSONNEL_SIGNATURE_CARD)
                .documentType("Personnel Signature Card")
                .files(null)
                .status("0")
                .build();

        given(mGetPreEmpUploadedDocumentInteractor.execute(anyString())).willReturn(Observable.just(mockPreEmpUploadedDocument));

        mPresenter.getDocumentStatus();

        verify(mView).showDocumentStatus(anyString());
    }
}
