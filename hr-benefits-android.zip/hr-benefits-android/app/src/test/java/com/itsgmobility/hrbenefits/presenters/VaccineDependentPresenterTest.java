package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.VaccineOtherDependentItem;
import com.itsgmobility.hrbenefits.ui.benefits.vaccine.vaccinefragment.VaccineDependentMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.vaccine.vaccinefragment.VaccineDependentPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class VaccineDependentPresenterTest extends PresenterTest {

    @InjectMocks
    VaccineDependentPresenter mPresenter;

    @Mock
    VaccineDependentMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldNotBuildDependent() {
        mPresenter.buildDependent();

        verify(mView).setFullNameStatus(any(Validation.class));
        verify(mView).setRelationshipStatus(any(Validation.class));
        verify(mView).setBirthDateStatus(any(Validation.class));
        verify(mView).setGenderStatus(any(Validation.class));
        verify(mView, never()).buildDependent(any(VaccineOtherDependentItem.class));
    }

    @Test
    public void shouldBuildDependent() {
        List<String> mockRelationship = new ArrayList<>();
        mockRelationship.add("test1");
        mockRelationship.add("test2");

        mPresenter.setRelationshipItems(mockRelationship);

        mPresenter.setFullName("test");
        mPresenter.setRelationship(0);
        mPresenter.setBirthDate(Calendar.getInstance().getTime());
        mPresenter.setGender(0);

        mPresenter.buildDependent();

        verify(mView).buildDependent(any(VaccineOtherDependentItem.class));
    }
}
