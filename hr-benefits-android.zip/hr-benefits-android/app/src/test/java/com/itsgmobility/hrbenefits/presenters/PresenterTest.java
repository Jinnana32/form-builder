package com.itsgmobility.hrbenefits.presenters;

import org.junit.Rule;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

public class PresenterTest {

    @Rule
    public final MockitoRule mMockitoRule = MockitoJUnit.rule();

    @Rule
    public final RxTestSchedulerRule mRxRule = new RxTestSchedulerRule();
}
