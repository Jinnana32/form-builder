package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.OnBoardingCertificateItem;
import com.itsgmobility.hrbenefits.ui.preemp.activity.certificate.OnBoardingCertificateMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.activity.certificate.OnBoardingCertificatePresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class OnBoardingCertificatePresenterTest extends PresenterTest {

    @InjectMocks
    OnBoardingCertificatePresenter mPresenter;

    @Mock
    OnBoardingCertificateMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldValidate() {
        mPresenter.submitForm();

        verify(mView).setCertificateStatus(any(Validation.class));
        verify(mView).setIssuingBodyStatus(any(Validation.class));
        verify(mView).setIssuedDateStatus(any(Validation.class));
        verify(mView, never()).submitForm(any(OnBoardingCertificateItem.class));
    }

    @Test
    public void shouldSubmit() {
        mPresenter.setCertificate("test");
        mPresenter.setIssuingBody("test");
        mPresenter.setIssuedDate("test");

        mPresenter.submitForm();

        verify(mView).submitForm(any(OnBoardingCertificateItem.class));
    }
}
