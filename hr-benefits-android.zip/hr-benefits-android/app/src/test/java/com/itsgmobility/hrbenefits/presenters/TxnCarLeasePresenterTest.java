package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.form.SubmitBenefitFeedbackInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.transaction.carlease.GetTxnCarLeasesInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.transaction.carlease.SendCarLeaseConfirmInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.transaction.carlease.SendCarLeasePaymentInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.transaction.carlease.SendCarLeaseReleaseInteractor;
import com.itsgmobility.hrbenefits.domain.model.CarDetail;
import com.itsgmobility.hrbenefits.domain.model.CarLeaseDetail;
import com.itsgmobility.hrbenefits.domain.model.Pair;
import com.itsgmobility.hrbenefits.domain.model.Status;
import com.itsgmobility.hrbenefits.domain.model.TxnAttachments;
import com.itsgmobility.hrbenefits.domain.model.TxnCarLeases;
import com.itsgmobility.hrbenefits.domain.repository.DeviceRepository;
import com.itsgmobility.hrbenefits.domain.repository.TransactionRepository;
import com.itsgmobility.hrbenefits.ui.benefits.transactions.carlease.TxnCarLeaseMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.transactions.carlease.TxnCarLeasePresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class TxnCarLeasePresenterTest extends PresenterTest {

    @InjectMocks
    TxnCarLeasePresenter mPresenter;

    @Mock
    GetTxnCarLeasesInteractor mGetTxnCarLeasesInteractor;

    @Mock
    SubmitBenefitFeedbackInteractor mSubmitBenefitFeedbackInteractor;

    @Mock
    SendCarLeasePaymentInteractor mSendCarLeasePaymentInteractor;

    @Mock
    SendCarLeaseConfirmInteractor mSendCarLeaseConfirmInteractor;

    @Mock
    SendCarLeaseReleaseInteractor mSendCarLeaseReleaseInteractor;

    @Mock
    TransactionRepository mTransactionRepository;

    @Mock
    DeviceRepository mDeviceRepository;

    @Mock
    TxnCarLeaseMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldShowUploadAttachment() {
        List<TxnAttachments> mockAttachments = new ArrayList<>();
        mockAttachments.add(new TxnAttachments("Asdasdas",
                "Asdasdas",
                "Asdasdas"));

        List<String> mockReqAttachment = new ArrayList<>();
        mockReqAttachment.add("Asd");

        TxnCarLeases txnCarLease = new TxnCarLeases(387612,
                new Status(TxnCarLeasePresenter.FOR_PAYMENT, "For Processing"),
                new CarLeaseDetail("12123123",
                        "1231231",
                        null,
                        mockAttachments,
                        new CarDetail(123123,
                                13123,
                                0,
                                "",
                                "",
                                "",
                                null,
                                "Salary Deduction",
                                "test",
                                mockReqAttachment)),
                "2018-06-20T08:22:31.000+0000");

        given(mGetTxnCarLeasesInteractor.execute(anyInt()))
                .willReturn(Single.just(new Pair<>(txnCarLease, "")));

        mPresenter.getTxnCarLease();

        verify(mView, never()).hideUploadAttachment();
    }

    @Test
    public void shouldHideUploadAttachment() {
        List<TxnAttachments> mockAttachments = new ArrayList<>();
        mockAttachments.add(new TxnAttachments("Asdasdas",
                "Asdasdas",
                "Asdasdas"));

        List<String> mockReqAttachment = new ArrayList<>();
        mockReqAttachment.add("Asd");

        TxnCarLeases txnCarLease = new TxnCarLeases(387612,
                new Status(TxnCarLeasePresenter.FOR_PAYMENT, "For Processing"),
                new CarLeaseDetail("12123123",
                        "1231231",
                        null,
                        mockAttachments,
                        new CarDetail(123123,
                                13123,
                                0,
                                "",
                                "",
                                "",
                                null,
                                "Salary Deduction",
                                "test",
                                new ArrayList<>())),
                "2018-06-20T08:22:31.000+0000");

        given(mGetTxnCarLeasesInteractor.execute(anyInt()))
                .willReturn(Single.just(new Pair<>(txnCarLease, "")));

        mPresenter.getTxnCarLease();

        verify(mView).hideUploadAttachment();
    }

    @Test
    public void shouldEnableConfirmReleaseButton() {
        List<TxnAttachments> mockAttachments = new ArrayList<>();
        mockAttachments.add(new TxnAttachments("Asdasdas",
                "Asdasdas",
                "Asdasdas"));

        List<String> mockReqAttachment = new ArrayList<>();
        mockReqAttachment.add("Asd");

        TxnCarLeases txnCarLease = new TxnCarLeases(387612,
                new Status(TxnCarLeasePresenter.FOR_PAYMENT, "For Processing"),
                new CarLeaseDetail("12123123",
                        "1231231",
                        null,
                        mockAttachments,
                        new CarDetail(123123,
                                13123,
                                0,
                                "",
                                "",
                                "",
                                null,
                                "Salary Deduction",
                                "test",
                                mockReqAttachment)),
                "2018-06-20T08:22:31.000+0000");

        given(mGetTxnCarLeasesInteractor.execute(anyInt()))
                .willReturn(Single.just(new Pair<>(txnCarLease, "")));

        mPresenter.getTxnCarLease();

        verify(mView).setConfirmReleaseButtonVisibility(txnCarLease.getTxnStatus().getId().equals(TxnCarLeasePresenter.FOR_RELEASING));
    }

    @Test
    public void shouldShowRequiredAttachment() {
        List<String> mockAttachments = new ArrayList<>();

        mockAttachments.add("test1");

        mPresenter.setAttachments(mockAttachments);

        mPresenter.uploadAttachment();

        verify(mView).showRequiredAttachment("test1");
    }
}
