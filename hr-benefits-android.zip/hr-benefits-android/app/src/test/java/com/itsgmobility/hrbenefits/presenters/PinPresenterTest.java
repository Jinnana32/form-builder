package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.ui.common.fragment.pin.PinMvpView;
import com.itsgmobility.hrbenefits.ui.common.fragment.pin.PinPresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.verify;

public class PinPresenterTest extends PresenterTest {

    @InjectMocks
    PinPresenter mPresenter;

    @Mock
    PinMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldSubmit_whenPinIs5() {
        mPresenter.addPin("1");
        mPresenter.addPin("2");
        mPresenter.addPin("3");
        mPresenter.addPin("4");
        mPresenter.addPin("5");

        verify(mView).submitPin("12345");
    }
}
