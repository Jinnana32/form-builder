package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.optical.SubmitOpticalFormInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.domain.param.SubmitOpticalFormParam;
import com.itsgmobility.hrbenefits.domain.resp.FormSubmitResp;
import com.itsgmobility.hrbenefits.ui.benefits.medical.optical.OpticalFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.optical.OpticalFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.MaxValueValidation;
import com.itsgmobility.hrbenefits.util.validate.RequiredValidation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class OpticalFormPresenterTest extends PresenterTest {

    @InjectMocks
    OpticalFormPresenter mPresenter;

    @Mock
    VisitModuleInteractor mVisitModuleInteractor;

    @Mock
    OpticalFormMvpView mView;

    @Mock
    SubmitOpticalFormInteractor mSubmitOpticalFormInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void submitFormForReview_validateAttachments() {
        List<String> mockRequiredAttachments = new ArrayList<>();

        mockRequiredAttachments.add("Official Receipt");
        mockRequiredAttachments.add("Official Receipt 2");

        mPresenter.setRequiredAttachments(mockRequiredAttachments);

        mPresenter.submitFormReview();

        verify(mView).setAttachmentStatus(eq(mockRequiredAttachments.get(0)), any(RequiredValidation.class));
        verify(mView).setAttachmentStatus(eq(mockRequiredAttachments.get(1)), any(RequiredValidation.class));
    }

    @Test
    public void submitFormForReview_validateAmountExceeded() {
        mPresenter.setLimit(1000);
        mPresenter.setAmount(2000);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setAmountStatus(any(MaxValueValidation.class));
    }

    @Test
    public void submitFormReview_shouldProceed() {
        List<String> mockRequiredAttachments = new ArrayList<>();

        mockRequiredAttachments.add("Official Receipt");
        mockRequiredAttachments.add("Official Receipt 2");

        mPresenter.setRequiredAttachments(mockRequiredAttachments);

        mPresenter.addAttachment("Official Receipt", mock(File.class));
        mPresenter.addAttachment("Official Receipt 2", mock(File.class));

        mPresenter.setLimit(2000);
        mPresenter.setAmount(2000);
        mPresenter.setOfficialReceiptNumber("test");
        mPresenter.setSchedule(Calendar.getInstance(), "test");

        mPresenter.submitFormReview();

        verify(mView).disableForm();
    }

    @Test
    public void submitForm_shouldSuccess() {
        given(mSubmitOpticalFormInteractor.execute(any(SubmitOpticalFormParam.class)))
                .willReturn(Single.just(FormSubmitResp.builder()
                        .benefitRequestId("1")
                        .formAgrees(new ArrayList<>())
                        .build()));

        mPresenter.submitForm();

        verify(mView).showLoading();
        verify(mView).hideLoading();
        verify(mView).onFormSubmitSuccess(new ArrayList<>(), "1");
    }
}