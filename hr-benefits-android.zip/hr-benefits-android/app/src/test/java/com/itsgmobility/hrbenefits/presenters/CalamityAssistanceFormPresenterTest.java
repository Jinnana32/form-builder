package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.CalamityTypeItem;
import com.itsgmobility.hrbenefits.common.item.DamagedPropertyItem;
import com.itsgmobility.hrbenefits.domain.interactor.calamity.SubmitCalamityFormInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.calamity.CalamityAssistanceFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.calamity.CalamityAssistanceFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class CalamityAssistanceFormPresenterTest extends PresenterTest {

    @InjectMocks
    CalamityAssistanceFormPresenter mPresenter;

    @Mock
    CalamityAssistanceFormMvpView mView;

    @Mock
    VisitModuleInteractor mVisitModuleInteractor;

    @Mock
    SubmitCalamityFormInteractor mSubmitCalamityFormInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void submitFormForReview_shouldValidateFields() {
        mPresenter.submitFormReview();

        verify(mView).setCalamityTypeStatus(any(Validation.class));
        verify(mView).setDateStatus(any(Validation.class));
        verify(mView).setBarangayCertificateAttachmentStatus(any(Validation.class));

        verify(mView, never()).disableForm();
    }

    @Test
    public void submitFormForReview_showFormReview() {
        List<CalamityTypeItem> mockCalamityTypes = new ArrayList<>();
        mockCalamityTypes.add(new CalamityTypeItem(0, "Fire"));

        mPresenter.setCalamityTypeItems(mockCalamityTypes);
        mPresenter.setCalamityType(0);

        mPresenter.setDate(Calendar.getInstance(), "test");
        mPresenter.addDamagedProperty(DamagedPropertyItem.builder()
                .id("0")
                .description("Test")
                .propertyName("Test")
                .propertyType("1")
                .repairCost(123)
                .acquisitionValue(123)
                .build());
        mPresenter.addBarangayCertificate(mock(File.class));

        mPresenter.submitFormReview();

        verify(mView).disableForm();
    }
}
