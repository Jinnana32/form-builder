package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.outpatient.SubmitOutpatientReimbursementFormInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.medical.outpatientreimbursement.OutpatientFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.outpatientreimbursement.OutpatientFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class OutpatientPresenterTest extends PresenterTest {

    @InjectMocks
    OutpatientFormPresenter mPresenter;

    @Mock
    SubmitOutpatientReimbursementFormInteractor mInteractor;

    @Mock
    OutpatientFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void submitFormReview_shouldValidateRequiredFields() {

        mPresenter.submitFormReview();

        verify(mView).setDependentStatus(any(Validation.class));
        verify(mView).setDateStatus(any(Validation.class));
        verify(mView).setOfficialReceiptNumberStatus(any(Validation.class));
        verify(mView).setDiagnosisStatus(any(Validation.class));

        verify(mView, never()).disableForm();
    }
}
