package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.DependentItem;
import com.itsgmobility.hrbenefits.domain.interactor.bereavement.SubmitBereavementFormInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.bereavement.BereavementMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.bereavement.BereavementPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class BereavementPresenterTest extends PresenterTest {

    @InjectMocks
    BereavementPresenter mPresenter;

    @Mock
    VisitModuleInteractor mVisitModuleInteractor;

    @Mock
    SubmitBereavementFormInteractor mSubmitBereavementFormInteractor;

    @Mock
    BereavementMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void onSubmitFormReview_ValidateRequiredFields() {
        mPresenter.setWithDeathCertificate(true);

        mPresenter.submitFormReview();

        verify(mView).setRelationshipStatus(any(Validation.class));
        verify(mView).setDeathDateStatus(any(Validation.class));

        verify(mView).setDateWakeStatus(any(Validation.class));
        verify(mView).setFAddressStatus(any(Validation.class));
        verify(mView).setFRegionStatus(any(Validation.class));
        verify(mView).setFProvinceStatus(any(Validation.class));
        verify(mView).setFCityStatus(any(Validation.class));

        verify(mView).setDateIntermentStatus(any(Validation.class));
        verify(mView).setIAddressStatus(any(Validation.class));
        verify(mView).setIRegionStatus(any(Validation.class));
        verify(mView).setIProvinceStatus(any(Validation.class));
        verify(mView).setICityStatus(any(Validation.class));

        verify(mView).setAttachmentStatus(any(Validation.class));

        verify(mView, never()).disableForm();
    }

    @Test
    public void onSubmitFormReview_showFormReview() {
        File mockFile = mock(File.class);
        List<DependentItem> dependentItemList = new ArrayList<>();

        dependentItemList.add(DependentItem.builder()
                .id(1)
                .name("test")
                .limit(0)
                .build());

        mPresenter.setDependentItems(dependentItemList);

        mPresenter.setRelationship("test");
        mPresenter.setDeceasedName(0);
        mPresenter.setAddressInterment("test");

        mPresenter.setFuneralHome("test");
        mPresenter.setFAddress("test");
        mPresenter.setFRegion("test");
        mPresenter.setProvince("test");
        mPresenter.setFCity("test");

        mPresenter.setMemorial("test");
        mPresenter.setRegionInterment("test");
        mPresenter.setProvinceInterment("test");
        mPresenter.setCityInterment("test");

        mPresenter.addDeathCertificate(mockFile);

        mPresenter.showDeathDate();
        mPresenter.setDate(Calendar.getInstance());

        Calendar wakeDate = Calendar.getInstance();
        wakeDate.add(Calendar.DAY_OF_MONTH, 1);

        mPresenter.showWakeDate();
        mPresenter.setDate(wakeDate);

        Calendar intermentDate = Calendar.getInstance();
        intermentDate.add(Calendar.DAY_OF_MONTH, 2);

        mPresenter.showIntermentDate();
        mPresenter.setDate(intermentDate);

        mPresenter.submitFormReview();

        verify(mView).disableForm();
    }

    @Test
    public void deathDateShouldNotAllowFuture() {
        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DAY_OF_MONTH, 1); // date today plus one day

        mPresenter.showDeathDate();
        mPresenter.setDate(calendar);

        verify(mView).showInvalidDeathDate();
    }

    @Test
    public void deathDateShouldAllowPresent() {
        Calendar calendar = Calendar.getInstance(); // date today

        mPresenter.showDeathDate();
        mPresenter.setDate(calendar);

        verify(mView, never()).showInvalidDeathDate();
    }

    @Test
    public void deathDateShouldAllowPast() {
        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DAY_OF_MONTH, -1); // date today minus 1 day

        mPresenter.showDeathDate();
        mPresenter.setDate(calendar);

        verify(mView, never()).showInvalidDeathDate();
    }

    @Test
    public void wakeDateShouldBeGreaterThanDeathDate() {
        Calendar calendarDeathDate = Calendar.getInstance();
        Calendar calendarWakeDate = Calendar.getInstance();

        calendarWakeDate.add(Calendar.DAY_OF_MONTH, -1);

        mPresenter.showDeathDate();
        mPresenter.setDate(calendarDeathDate);

        mPresenter.showWakeDate();
        mPresenter.setDate(calendarWakeDate);


        verify(mView).showInvalidWakeDate();
    }

    @Test
    public void intermentDateShouldBeGreaterThanWakeDate() {
        Calendar calendarDeathDate = Calendar.getInstance();
        Calendar calendarIntermentDate = Calendar.getInstance();
        Calendar calendarWakeDate = Calendar.getInstance();

        calendarDeathDate.add(Calendar.DAY_OF_MONTH, -2);
        calendarIntermentDate.add(Calendar.DAY_OF_MONTH, -1);

        mPresenter.showDeathDate();
        mPresenter.setDate(calendarDeathDate);

        mPresenter.showWakeDate();
        mPresenter.setDate(calendarWakeDate);

        mPresenter.showIntermentDate();
        mPresenter.setDate(calendarIntermentDate);


        verify(mView).showInvalidIntermentDate();
    }
}
