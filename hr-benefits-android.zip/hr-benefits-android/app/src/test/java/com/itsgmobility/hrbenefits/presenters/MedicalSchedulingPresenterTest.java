package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.ClinicPackagesItem;
import com.itsgmobility.hrbenefits.common.item.ClinicsItem;
import com.itsgmobility.hrbenefits.common.item.MedicalSchedulingProceduresItem;
import com.itsgmobility.hrbenefits.domain.interactor.medicalscheduling.GetMedicalSchedulingBranchesInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.medicalscheduling.SubmitMedicalSchedulingFormInteractor;
import com.itsgmobility.hrbenefits.ui.benefits.medical.medicalscheduling.MedicalSchedulingMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.medicalscheduling.MedicalSchedulingPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;

public class MedicalSchedulingPresenterTest extends PresenterTest {

    @InjectMocks
    MedicalSchedulingPresenter mPresenter;

    @Mock
    MedicalSchedulingMvpView mView;

    @Mock
    SubmitMedicalSchedulingFormInteractor submitMedicalSchedulingFormInteractor;

    @Mock
    GetMedicalSchedulingBranchesInteractor getMedicalSchedulingBranchesInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldProceedToFormReview() {
        mPresenter.submitFormReview();

        verify(mView).setClinicStatus(any(Validation.class));
        verify(mView).setPackagesStatus(any(Validation.class));
        verify(mView).setDateStatus(any(Validation.class));
    }

    @Test
    public void shouldShowPreferredSchedule() {
        Calendar calendar = Calendar.getInstance();
        mPresenter.setDate(calendar, anyString());
        mView.showPreferredSchedule(anyString());
    }

    @Test
    public void shouldEnablePackageDialog() {
        List<ClinicsItem> mockClinics = new ArrayList<>();
        List<MedicalSchedulingProceduresItem> mockProcedures = new ArrayList<>();
        List<ClinicPackagesItem> mockClinicsPackages = new ArrayList<>();

        ClinicsItem mockClinic = new ClinicsItem("TEST", "TEST", mockClinicsPackages);

        MedicalSchedulingProceduresItem mockProcedure = new MedicalSchedulingProceduresItem(0, "TEST", true);

        mockProcedures.add(mockProcedure);

        ClinicPackagesItem mockClinicPackages = new ClinicPackagesItem(0, "TEST", mockProcedures);

        mockClinicsPackages.add(mockClinicPackages);
        mockClinics.add(mockClinic);

        mPresenter.setClinicsItem(mockClinics);

        mPresenter.setClinic(anyInt());

        verify(mView).setClinicStatus(mPresenter.getClinicValidation());
        verify(mView).showClinicText(anyString());
        verify(mView).enablePackageDialog();
    }

    @Test
    public void shouldShowPackages() {
        shouldEnablePackageDialog();
        mPresenter.setPackage(anyInt());

        verify(mView).setPackagesStatus(mPresenter.getPackagesValidation());
        verify(mView).showPackageText(anyString());
    }
}
