package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.common.interactor.StartMainAppInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.device.GetNameInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.AgreeTermsAndConditionsInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.ClearSessionInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.LoginInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.ProceedBiometricsInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.ValidateBiometricsAuthenticator;
import com.itsgmobility.hrbenefits.domain.interactor.user.VerifyOtpInteractor;
import com.itsgmobility.hrbenefits.domain.model.Authenticator;
import com.itsgmobility.hrbenefits.domain.model.Optional;
import com.itsgmobility.hrbenefits.domain.model.TermsAndCondition;
import com.itsgmobility.hrbenefits.domain.resp.LoginResp;
import com.itsgmobility.hrbenefits.ui.generic.login.LoginMvpView;
import com.itsgmobility.hrbenefits.ui.generic.login.LoginPresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

public class LoginPresenterTest extends PresenterTest {

    private static final String TEST_USERNAME = "test";
    private static final String TEST_PASSWORD = "test";

    @InjectMocks
    LoginPresenter mPresenter;

    @Mock
    LoginInteractor mLoginInteractor;

    @Mock
    VerifyOtpInteractor mVerifyOtpInteractor;

    @Mock
    ValidateBiometricsAuthenticator mValidateBiometricsAuthenticator;

    @Mock
    ClearSessionInteractor mClearSessionInteractor;

    @Mock
    AgreeTermsAndConditionsInteractor mAgreeTermsAndConditionsInteractor;

    @Mock
    StartMainAppInteractor mStartMainAppInteractor;

    @Mock
    ProceedBiometricsInteractor mProceedBiometericsInteractor;

    @Mock
    GetNameInteractor mGetNameInteractor;

    @Mock
    LoginMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldShowLoginSuccess() {
        LoginResp mockResp = new LoginResp("Login successful. Proceed with the authentication",
                new Authenticator(Authenticator.OTP, "OTP"),
                "sampletoken",
                new Optional<>(TermsAndCondition.builder().accepted(true).content("Sample sample sameple").build()));

        given(mLoginInteractor.execute(any(LoginInteractor.Params.class))).willReturn(Single.just(mockResp));

        mPresenter.setUsername(TEST_USERNAME);
        mPresenter.setPassword(TEST_PASSWORD);
        mPresenter.login();

        verify(mView).showLoading();
        verify(mView).showOtp("Login successful. Proceed with the authentication", "");
    }

    @Test
    public void shouldShowBiometrics() {
        given(mValidateBiometricsAuthenticator.execute())
                .willReturn(Single.just(new Optional<>(null)));

        mPresenter.validateBiometrics();

        verify(mView).showLoading();
        verify(mView).showMainPage();
    }

    @Test
    public void shouldShowTermsAndConditions() {
        TermsAndCondition mockResp = TermsAndCondition.builder()
                .accepted(false)
                .content("test")
                .build();

        given(mValidateBiometricsAuthenticator.execute())
                .willReturn(Single.just(new Optional<>(mockResp)));
        mPresenter.validateBiometrics();

        verify(mView).showTermsAndConditions("test");
    }
}
