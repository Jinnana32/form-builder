package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.model.PreEmpWork;
import com.itsgmobility.hrbenefits.ui.preemp.activity.workexperience.PreEmpWorkFormMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.activity.workexperience.PreEmpWorkFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.Calendar;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class PreEmpWorkPresenterTest extends PresenterTest {

    @InjectMocks
    PreEmpWorkFormPresenter mPresenter;

    @Mock
    PreEmpWorkFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldValidate() {
        mPresenter.submitForm();

        verify(mView).setCompanyStatus(any(Validation.class));
        verify(mView).setAddressStatus(any(Validation.class));
        verify(mView).setPositionStatus(any(Validation.class));
        verify(mView).setMonthFromStatus(any(Validation.class));
        verify(mView).setYearFromStatus(any(Validation.class));
        verify(mView).setMonthToStatus(any(Validation.class));
        verify(mView).setYearToStatus(any(Validation.class));
        verify(mView).setDescriptionStatus(any(Validation.class));

        verify(mView, never()).submitForm(any(PreEmpWork.class));
    }

    @Test
    public void shouldSubmit() {
        mPresenter.setCompany("test");
        mPresenter.setAddress("test");
        mPresenter.setPosition("test");
        mPresenter.setFromMonth(Calendar.JANUARY);
        mPresenter.setToMonth(Calendar.JANUARY);
        mPresenter.setFromYear(Calendar.getInstance().get(Calendar.YEAR) - 1);
        mPresenter.setToYear(Calendar.getInstance().get(Calendar.YEAR));
        mPresenter.setDescription("test");
        mPresenter.setContactNumber("09758512314");

        mPresenter.submitForm();

        verify(mView).submitForm(any(PreEmpWork.class));
    }
}
