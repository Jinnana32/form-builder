package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.preemp.AffirmDocumentInteractor;
import com.itsgmobility.hrbenefits.domain.model.PreEmpAffirmDocument;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.affirmdocument.activity.AffirmDocumentMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.affirmdocument.activity.AffirmDocumentPresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.File;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class AffirmDocumentPresenterTest extends PresenterTest {

    @InjectMocks
    AffirmDocumentPresenter mPresenter;

    @Mock
    AffirmDocumentMvpView mView;

    @Mock
    AffirmDocumentInteractor mAffirmDocumentInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldNotProceedWhenNotCompleted() {
        mPresenter.setPreEmpDocument(PreEmpAffirmDocument.builder()
                .file(mock(File.class))
                .url("")
                .status(PreEmpAffirmDocument.NOT_AFFIRMED)
                .id(PreEmpAffirmDocument.PRE_EMPLOYMENT_UNDERTAKING)
                .build());

        mPresenter.affirmDocument();

        verify(mView).showNotCompletedDocument(PreEmpAffirmDocument.PRE_EMPLOYMENT_UNDERTAKING);
        verify(mView, never()).showPinCodeDialog();
    }

    @Test
    public void shouldProceedWhenCompleted() {
        mPresenter.setPreEmpDocument(PreEmpAffirmDocument.builder()
                .file(mock(File.class))
                .url("")
                .status(PreEmpAffirmDocument.NOT_AFFIRMED)
                .id(PreEmpAffirmDocument.PRE_EMPLOYMENT_UNDERTAKING)
                .build());

        mPresenter.setLastPageReached(true);

        mPresenter.affirmDocument();

        verify(mView, never()).showNotCompletedDocument(PreEmpAffirmDocument.PRE_EMPLOYMENT_UNDERTAKING);
        verify(mView).showPinCodeDialog();
    }

    @Test
    public void shouldHideAffirmButton() {
        mPresenter.setPreEmpDocument(PreEmpAffirmDocument.builder()
                .file(mock(File.class))
                .url("")
                .status(PreEmpAffirmDocument.AFFIRMED)
                .id(PreEmpAffirmDocument.PRE_EMPLOYMENT_UNDERTAKING)
                .build());

        verify(mView).setAffirmButtonVisibility(false);
    }
}
