package com.itsgmobility.hrbenefits.presenters;

import android.annotation.SuppressLint;

import com.codetroopers.betterpickers.Utils;
import com.itsgmobility.hrbenefits.data.util.DateUtil;
import com.itsgmobility.hrbenefits.ui.leave.LeaveMvpView;
import com.itsgmobility.hrbenefits.ui.leave.LeavePresenter;
import com.itsgmobility.hrbenefits.ui.leave.LeaveValidation;
import com.itsgmobility.hrbenefits.util.validate.DateValidation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.text.ParseException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class LeavePresenterTest extends PresenterTest {

    @InjectMocks
    LeavePresenter mPresenter;

    @Mock
    LeaveMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldInvalidToDate() throws ParseException {
        /* format: yyyy-MM-dd HH:mm:ss */
        String fromDateString = "2018-01-02T00:00:00";
        String toDateString = "2018-01-01T00:00:00";

        Calendar fromDate = Calendar.getInstance();
        fromDate.setTime(DateUtil.parseDate(fromDateString, DateUtil.RAW_FORMAT_DATE_3));

        Calendar toDate = Calendar.getInstance();
        toDate.setTime(DateUtil.parseDate(toDateString, DateUtil.RAW_FORMAT_DATE_3));

        mPresenter.setFromDate(fromDate);
        mPresenter.setToDate(toDate);

        verify(mView).setToDateStatus(any(DateValidation.class));
        verify(mView).setToTimeStatus(any(DateValidation.class));
    }

    @Test
    public void shouldInvalidFromDate() throws ParseException {
        /* format: yyyy-MM-dd HH:mm:ss */
        String fromDateString = "2018-01-02T00:00:00";
        String toDateString = "2018-01-01T00:00:00";

        Calendar fromDate = Calendar.getInstance();
        fromDate.setTime(DateUtil.parseDate(fromDateString, DateUtil.RAW_FORMAT_DATE_3));

        Calendar toDate = Calendar.getInstance();
        toDate.setTime(DateUtil.parseDate(toDateString, DateUtil.RAW_FORMAT_DATE_3));

        mPresenter.setToDate(toDate);
        mPresenter.setFromDate(fromDate);

        verify(mView).setFromDateStatus(any(DateValidation.class));
        verify(mView).setFromTimeStatus(any(DateValidation.class));
    }

    @Test
    public void shouldInvalidDateSpan() throws ParseException {
        /* format: yyyy-MM-dd HH:mm:ss */
        String minDateString = "2018-01-01T00:00:00";
        String maxDateString = "2018-02-01T00:00:00";

        Calendar minDate = Calendar.getInstance();
        minDate.setTime(DateUtil.parseDate(minDateString, DateUtil.RAW_FORMAT_DATE_3));

        Calendar maxDate = Calendar.getInstance();
        maxDate.setTime(DateUtil.parseDate(maxDateString, DateUtil.RAW_FORMAT_DATE_3));

        // Disable all weekends from death date to 1 month after death date
        @SuppressLint("UseSparseArrays") Map<String, Calendar> disabledDays = new HashMap<>();

        Calendar startCal = Calendar.getInstance();
        startCal.setTimeInMillis(minDate.getTimeInMillis());
        Calendar endCal = Calendar.getInstance();
        endCal.setTimeInMillis(maxDate.getTimeInMillis());

        while (startCal.before(endCal)) {
            if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
                    || startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) { // if the date is sat or sun
                int key = Utils.formatDisabledDayForKey(startCal.get(Calendar.YEAR),
                        startCal.get(Calendar.MONTH), startCal.get(Calendar.DAY_OF_MONTH));

                disabledDays.put(String.valueOf(key), startCal);
            }

            startCal.add(Calendar.DATE, 1); // add 1 day
        }

        mPresenter.setLeaveValidation(LeaveValidation.builder()
                .minDate(minDate)
                .maxDate(maxDate)
                .disabledDays(disabledDays)
                .validSpan(3)
                .build());

        Calendar mockToDate = Calendar.getInstance();
        mockToDate.setTimeInMillis(minDate.getTimeInMillis());
        mockToDate.add(Calendar.DAY_OF_MONTH, 5);

        mPresenter.setFromDate(minDate);
        mPresenter.setToDate(mockToDate);

        mPresenter.submitLeave();

        verify(mView).showInvalidDateSpan(3);
    }

    @Test
    public void shouldNotSubmitLeave() {
        mPresenter.submitLeave();

        verify(mView, never()).submitLeave(null);
    }
}
