package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.ui.cocdetail.CocMvpView;
import com.itsgmobility.hrbenefits.ui.cocdetail.CocPresenter;
import com.itsgmobility.hrbenefits.domain.interactor.compliance.GetCocInteractor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import com.itsgmobility.hrbenefits.domain.interactor.coc.GetHasCocInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.user.VisitModuleInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.compliance.AcknowledgeCocInteractor;
public class CocPresenterTest extends PresenterTest {

    @InjectMocks
    CocPresenter mPresenter;

    @Mock
    GetCocInteractor mGetCocInteractor;

    @Mock
    GetHasCocInteractor mGetHasCocInteractor;

    @Mock
    VisitModuleInteractor mVisitModuleInteractor;

    @Mock
    AcknowledgeCocInteractor mAcknowledgeCocInteractor;


    @Mock
    CocMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldNotProceedWhenNotCompleted() {
        mPresenter.acknowledgeCoc();

        verify(mView).showNotCompletedCoc();
        verify(mView, never()).showPinCodeDialog();
    }

    @Test
    public void shouldProceedWhenCompleted() {
        mPresenter.setLastPageReached(true);

        mPresenter.acknowledgeCoc();

        verify(mView, never()).showNotCompletedCoc();
        verify(mView).showPinCodeDialog();
    }
}
