package com.itsgmobility.hrbenefits.util.validate;

import org.junit.Assert;
import org.junit.Test;

public class ValidationTest {

    @Test
    public void alphabetOnly() {
        Assert.assertFalse(new AlphabetValidation().isValid("123abc"));
        Assert.assertFalse(new AlphabetValidation().isValid("!@#$%^&*()][';/.,`\\{}:\"<>?|_+-=abc"));
        Assert.assertTrue(new AlphabetValidation().isValid("abcdefghijklmnopqrstuvwxyz"));
        Assert.assertTrue(new AlphabetValidation().isValid("abcdefghijkl mnopqrstuvwxyz"));
    }

    @Test
    public void alphaNumericOnly() {
        Assert.assertFalse(new AlphaNumericValidation().isValid("!@#$%^&*()][';/.,`\\{}:\"<>?|_+-=abc"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("abcdefghijklmnopqrstuvwxyz"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("abcdefghijk lmnopqrstuvwxyz"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("1234567890"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("1234 567890"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("1234567890abcdefghijklmnopqrstuvwxyz"));
        Assert.assertTrue(new AlphaNumericValidation().isValid("1234567890abcdef ghijklmnopqrstuvwxyz"));
    }

    @Test
    public void requireValidation() {
        Assert.assertTrue(new RequiredValidation().isValid("test"));
        Assert.assertFalse(new RequiredValidation().isValid(""));
    }
}
