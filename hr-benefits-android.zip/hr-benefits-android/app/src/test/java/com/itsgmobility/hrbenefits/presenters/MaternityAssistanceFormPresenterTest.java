package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.DeliveryTypeItem;
import com.itsgmobility.hrbenefits.ui.benefits.medical.maternityassistance.MaternityAssistanceFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.maternityassistance.MaternityAssistanceFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.MinMaxValidation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class MaternityAssistanceFormPresenterTest extends PresenterTest {

    @InjectMocks
    MaternityAssistanceFormPresenter mPresenter;

    @Mock
    MaternityAssistanceFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    /**
     * should not allow greater than 20 OR number characters
     */
    @Test
    public void shouldNotAllowGreaterThan20OrNumberCharacters() {
        mPresenter.setOrNumber("123456789012345678901");

        verify(mView).setOrNumberStatus(any(MinMaxValidation.class));
    }

    /**
     * should allow less than or equal 20 OR number characters
     */
    @Test
    public void shouldAllowLessOrEqual20OrNumberCharacters() {
        mPresenter.setOrNumber("12345678901234567890");

        verify(mView, never()).setOrNumberStatus(any(MinMaxValidation.class));
    }

    @Test
    public void shouldShowOfficialReceiptIfPastDate() {
        Calendar dateToday = Calendar.getInstance(); // get date today

        mPresenter.showDateOfDeliveryPicker();
        mPresenter.setDate(dateToday);

        verify(mView).setOrDateVisibility(true);
        verify(mView).setOrNumberVisibility(true);
    }

    @Test
    public void shouldNotShowOfficialReceiptIfFutureDate() {
        Calendar dateTodayPlusOne = Calendar.getInstance(); // get date today

        dateTodayPlusOne.add(Calendar.DAY_OF_MONTH, 1);

        mPresenter.showDateOfDeliveryPicker();
        mPresenter.setDate(dateTodayPlusOne);

        verify(mView).setOrDateVisibility(false);
        verify(mView).setOrNumberVisibility(false);
    }

    @Test
    public void shouldSubmitFormForReviewIfNoOfficialReceipt() {
        Calendar dateTodayPlusOne = Calendar.getInstance(); // get date today

        dateTodayPlusOne.add(Calendar.DAY_OF_MONTH, 1);

        mPresenter.showDateOfDeliveryPicker();
        mPresenter.setDate(dateTodayPlusOne);

        List<DeliveryTypeItem> mockDeliveryTypeItems = new ArrayList<>();
        mockDeliveryTypeItems.add(DeliveryTypeItem.builder()
                .id(1)
                .name("Normal")
                .build());

        mPresenter.setDeliveryTypeItems(mockDeliveryTypeItems);
        mPresenter.setSelectedTypeOfDelivery(0);

        mPresenter.setAmount(100);
        mPresenter.setDepenpent("test");
        mPresenter.addAttachment(MaternityAssistanceFormPresenter.STATEMENT_OF_ACCOUNT, mock(File.class));
        mPresenter.addAttachment(MaternityAssistanceFormPresenter.SIGNED_OBSTERICAL_HISTORY, mock(File.class));

        mPresenter.submitFormReview();

        verify(mView).disableForm();
    }

    @Test
    public void shouldNotSubmitFormForReviewIfHasOfficialReceipt() {
        Calendar dateTodayPlusOne = Calendar.getInstance(); // get date today

        mPresenter.showDateOfDeliveryPicker();
        mPresenter.setDate(dateTodayPlusOne);

        List<DeliveryTypeItem> mockDeliveryTypeItems = new ArrayList<>();
        mockDeliveryTypeItems.add(DeliveryTypeItem.builder()
                .id(1)
                .name("Normal")
                .build());

        mPresenter.setDeliveryTypeItems(mockDeliveryTypeItems);
        mPresenter.setSelectedTypeOfDelivery(0);

        mPresenter.setAmount(100);
        mPresenter.setDepenpent("test");
        mPresenter.addAttachment(MaternityAssistanceFormPresenter.STATEMENT_OF_ACCOUNT, mock(File.class));
        mPresenter.addAttachment(MaternityAssistanceFormPresenter.SIGNED_OBSTERICAL_HISTORY, mock(File.class));

        mPresenter.submitFormReview();

        verify(mView, never()).disableForm();
    }
}
