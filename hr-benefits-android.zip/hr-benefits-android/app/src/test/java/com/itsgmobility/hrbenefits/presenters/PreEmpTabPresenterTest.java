package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.ui.preemp.PreEmpTabPresenter;
import com.itsgmobility.hrbenefits.ui.preemp.PreEmpTabMvpView;

import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;

public class PreEmpTabPresenterTest extends PresenterTest {

    @InjectMocks
    PreEmpTabPresenter mPresenter;

    @Mock
    PreEmpTabMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }
}
