package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.ui.generic.review.ReviewMvpView;
import com.itsgmobility.hrbenefits.ui.generic.review.ReviewPresenter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class ReviewPresenterTest extends PresenterTest {

    @InjectMocks
    ReviewPresenter mPresenter;

    @Mock
    ReviewMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldShowFeedbackDialog() {
        mPresenter.setRating(3);
        mPresenter.submitRating();

        verify(mView).showFeedbackDialog();
    }

    @Test
    public void shouldNotShowFeedbackDialog() {
        mPresenter.setRating(4);
        mPresenter.submitRating();

        verify(mView, never()).showFeedbackDialog();
    }

    @Test
    public void shouldShowPositiveFeedback() {
        mPresenter.withPositiveFeedback(true);
        mPresenter.setRating(4);

        mPresenter.submitRating();

        verify(mView).showPositiveFeedback();
    }

    @Test
    public void shouldNotShowPositiveFeedback() {
        mPresenter.withPositiveFeedback(false);
        mPresenter.setRating(4);

        mPresenter.submitRating();

        verify(mView, never()).showPositiveFeedback();
    }
}
