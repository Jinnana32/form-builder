package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.OffsetItem;
import com.itsgmobility.hrbenefits.common.item.TermItem;
import com.itsgmobility.hrbenefits.domain.interactor.device.GetMcInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.mpl.GetMplAttachmentsInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.mpl.GetMplPurposesInteractor;
import com.itsgmobility.hrbenefits.domain.model.MplPurpose;
import com.itsgmobility.hrbenefits.domain.model.MplType;
import com.itsgmobility.hrbenefits.domain.resp.MplPurposeResp;
import com.itsgmobility.hrbenefits.ui.benefits.multipurposeloan.form.MplFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.multipurposeloan.form.MplFormPresenter;
import com.itsgmobility.hrbenefits.util.NumberUtil;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

public class MplFormPresenterTest extends PresenterTest {

    @InjectMocks
    MplFormPresenter mPresenter;

    @Mock
    MplFormMvpView mView;

    @Mock
    GetMcInteractor mGetMcInteractor;

    @Mock
    GetMplPurposesInteractor mGetMplPurposesInteractor;

    @Mock
    GetMplAttachmentsInteractor mGetMplAttachmentsInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldValidateForm() {
        mPresenter.submitFormReview();

        verify(mView).setPurposeOfLoanStatus(any(Validation.class));
        verify(mView).setModeOfLoanStatus(any(Validation.class));
        verify(mView).setAmountStatus(any(Validation.class));
        verify(mView).setTermStatus(any(Validation.class));

        verify(mView, never()).showEmptyOffsetsError();
        verify(mView, never()).setAttachmentStatus(anyString(), any(Validation.class));
    }

    @Test
    public void shouldPreFillPurpose() {
        mPresenter = spy(mPresenter);

        List<MplPurpose> mockPurposes = new ArrayList<>();
        mockPurposes.add(MplPurpose.builder()
                .id(0)
                .name("test")
                .image("test")
                .status(0)
                .build());

        MplPurposeResp mockResp = MplPurposeResp.builder()
                .mplPurposes(mockPurposes)
                .subCategoryLvl(0)
                .build();

        given(mGetMplPurposesInteractor.execute(any(GetMplPurposesInteractor.Params.class))).willReturn(Single.just(mockResp));

        mPresenter.checkPurposeForPreFill();

        verify(mView).disablePurpose();
        verify(mView).showPurposeText(anyString());
        verify(mPresenter, atLeastOnce()).getAttachments(anyString(), anyInt());
    }

    @Test
    public void shouldShowNewLoan() {
        mPresenter.setModeOfLoan(0);

        verify(mView).showModeOfLoanText("New Loan");
    }

    @Test
    public void shouldHideOffsetWhenNewLoan() {
        mPresenter.setModeOfLoan(0);

        verify(mView).setOffsetLoanVisibility(false);
    }

    @Test
    public void shouldShowOffsetLoan() {
        mPresenter.setModeOfLoan(1);

        verify(mView).showModeOfLoanText("Offset Loan");
        verify(mView).setOffsetLoanVisibility(true);
    }

    @Test
    public void shouldShowTermText() {
        List<TermItem> mockTermItems = new ArrayList<>();

        mockTermItems.add(TermItem.builder()
                .id(1)
                .interest(10)
                .term("6")
                .build());

        mockTermItems.add(TermItem.builder()
                .id(2)
                .interest(20)
                .term("7")
                .build());

        mPresenter.setTermItems(mockTermItems);
        mPresenter.setChosenTerm(1);

        verify(mView).showTermText("7 (20.0%)");
        verify(mView).setTermStatus(null);
    }

    @Test
    public void shouldPreFillNewLoan() {
        List<OffsetItem> mockOffsetItems = new ArrayList<>();
        mPresenter.setOffsetItems(mockOffsetItems);

        verify(mView).preFillNewLoan();

        mPresenter.submitFormReview();

        verify(mView, never()).setModeOfLoanStatus(any(Validation.class));
    }

    @Test
    public void shouldShowOffsetDialogWithSelected() {
        List<OffsetItem> mockOffsetItems = new ArrayList<>();

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO1")
                .outstandingBalance(10)
                .build());

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO2")
                .outstandingBalance(20)
                .build());

        mPresenter.setOffsetItems(mockOffsetItems);

        mPresenter.showOffsetLoanDialog();

        verify(mView).showOffsetLoanDialog(new String[]{
                String.format("%s<br><small>%s %s</small>",
                        "SO1", NumberUtil.PESO_SIGN,
                        NumberUtil.formatTwoDecimal(10)),
                String.format("%s<br><small>%s %s</small>",
                        "SO2", NumberUtil.PESO_SIGN,
                        NumberUtil.formatTwoDecimal(20))
        }, new boolean[]{false, false});
    }

    @Test
    public void shouldNotAddWhenExceeds() {
        List<OffsetItem> mockOffsetItems = new ArrayList<>();

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO1")
                .outstandingBalance(10)
                .build());

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO2")
                .outstandingBalance(20)
                .build());

        mPresenter.setOffsetItems(mockOffsetItems);

        mPresenter.setChosenOffsetItems(new boolean[]{false, true});

        verify(mView).showTotalOffsetBalanceExceed();
        verify(mView, never()).showOffsets(anyList());
    }

    @Test
    public void shouldAddWhenNotExceeds() {
        List<OffsetItem> mockOffsetItems = new ArrayList<>();

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO1")
                .outstandingBalance(10)
                .build());

        mockOffsetItems.add(OffsetItem.builder()
                .promissoryNoteNumber("SO2")
                .outstandingBalance(20)
                .build());

        mPresenter.setOffsetItems(mockOffsetItems);
        mPresenter.setAmount(30);

        mPresenter.setChosenOffsetItems(new boolean[]{true, true});

        verify(mView, never()).showTotalOffsetBalanceExceed();
        verify(mView).showOffsets(anyList());
    }

    @Test
    public void shouldShowAttachmentsWhenNotEmpty() {
        List<String> mockAttachments = new ArrayList<>();
        mockAttachments.add("attachment 1");

        mPresenter.setRequiredAttachments(mockAttachments, mockAttachments);

        verify(mView).setAttachmentsVisibility(true);
        verify(mView).initAttachments(anyList());
    }

    @Test
    public void shouldNotShowAttachmentsWhenEmpty() {
        mPresenter.setRequiredAttachments(null, null);

        verify(mView).setAttachmentsVisibility(false);
        verify(mView, never()).initAttachments(anyList());
    }

    @Test
    public void shouldCheckPurposePreFill_WhenLoanIdSupplied() {
        mPresenter = spy(mPresenter);

        mPresenter.setLoanId(0);

        verify(mPresenter, atLeastOnce()).checkPurposeForPreFill();
    }

    @Test
    public void shouldShowPayeeNameIfComputerLoan() {
        mPresenter.setLoanId(MplType.COMPUTER_LOAN);

        verify(mView).showComputerLoanPayeeName();
        verify(mView).setPayeeName("");
    }

    @Test
    public void shouldShowPayeeNameIfMotorLoan() {
        mPresenter.setLoanId(MplType.MOTORCYCLE_LOAN);

        verify(mView).showMotorLoanPayeeName();
        verify(mView).setPayeeName("");
    }

    @Test
    public void shouldHidePayeeNameIfNotComputerOrMotorLoan() {
        mPresenter.setLoanId(MplType.SALARY_LOAN);

        verify(mView).hidePayeeName();
    }
}
