package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.domain.interactor.preemp.GetCollegesInteractor;
import com.itsgmobility.hrbenefits.domain.model.PreEmpEducation;
import com.itsgmobility.hrbenefits.domain.model.PreEmpSchool;
import com.itsgmobility.hrbenefits.domain.resp.CollegesResp;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.preempeducation.education.PreEmpEducationMvpView;
import com.itsgmobility.hrbenefits.ui.preemp.fragments.preempeducation.education.PreEmpEducationPresenter;
import com.itsgmobility.hrbenefits.util.validate.Validation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class PreEmpEducationPresenterTest extends PresenterTest {

    @InjectMocks
    PreEmpEducationPresenter mPresenter;

    @Mock
    PreEmpEducationMvpView mView;

    @Mock
    GetCollegesInteractor mCollegeInteractor;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldValidate() {
        mPresenter.submitForm();

        verify(mView).setCollegeStatus(any(Validation.class));
        verify(mView).setDegreeStatus(any(Validation.class));
        verify(mView).setCourseStatus(any(Validation.class));
        verify(mView).setYearFromStatus(any(Validation.class));
        verify(mView).setYearToStatus(any(Validation.class));

        verify(mView, never()).submitForm(any(PreEmpEducation.class));
    }

    @Test
    public void shouldSubmit() {
        List<PreEmpSchool> mockColleges = new ArrayList<>();

        mockColleges.add(PreEmpSchool.builder()
                .id("1")
                .name("test")
                .build());

        given(mCollegeInteractor.execute(any())).willReturn(Single.just(CollegesResp.builder()
                .colleges(mockColleges)
                .totalCount(10)
                .build()));

        mPresenter.setCollegeItem(PreEmpSchool.builder()
                .id("1")
                .name("test")
                .build());
        mPresenter.setDegree(1);
        mPresenter.setCourse("test");
        mPresenter.setYearFrom(2014);
        mPresenter.setToYear(2015);
        mPresenter.setAddress("test");

        mPresenter.submitForm();

        verify(mView).submitForm(any(PreEmpEducation.class));
    }
}
