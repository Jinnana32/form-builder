package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.ui.benefits.medical.maternityassistance.maternitysss.MaternitySSSFormMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.medical.maternityassistance.maternitysss.MaternitySSSFormPresenter;
import com.itsgmobility.hrbenefits.util.validate.MaxValueValidation;
import com.itsgmobility.hrbenefits.util.validate.MinMaxValidation;
import com.itsgmobility.hrbenefits.util.validate.MinValueValidation;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class MaternitySSSFormPresenterTest extends PresenterTest {

    @InjectMocks
    MaternitySSSFormPresenter mPresenter;

    @Mock
    MaternitySSSFormMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldNotProceed_deliveryGreaterPregnancy() {
        mPresenter.setNumberOfPregnancyIndex(3);
        mPresenter.setNumberOfDelivery(6);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setNumberOfDeliveryStatus(any(MaxValueValidation.class));
    }

    @Test
    public void shouldNotProceed_miscarriageGreaterPregnancy() {
        mPresenter.setNumberOfPregnancyIndex(3);
        mPresenter.setNumberOfMiscarriage(6);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setNumberOfMiscarriageStatus(any(MaxValueValidation.class));
    }

    @Test
    public void shouldNotProceed_totalMiscarriageAndDeliveryGreaterThanPregnancy() {
        mPresenter.setNumberOfPregnancyIndex(3);
        mPresenter.setNumberOfMiscarriage(4);
        mPresenter.setNumberOfDelivery(4);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setNumberOfDeliveryStatus(any(MaxValueValidation.class));
        verify(mView, atLeastOnce()).setNumberOfMiscarriageStatus(any(MaxValueValidation.class));
    }

    @Test
    public void shouldNotProceed_totalMiscarriageAndDeliveryLessThanPregnancy() {
        mPresenter.setNumberOfPregnancyIndex(3);
        mPresenter.setNumberOfMiscarriage(3);
        mPresenter.setNumberOfDelivery(0);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setNumberOfDeliveryStatus(any(MinValueValidation.class));
        verify(mView, atLeastOnce()).setNumberOfMiscarriageStatus(any(MinValueValidation.class));
    }

    @Test
    public void shouldProceed_totalMiscarriageAndDeliveryEqualPregnancy() {
        mPresenter.setNumberOfPregnancyIndex(3);
        mPresenter.setNumberOfMiscarriage(2);
        mPresenter.setNumberOfDelivery(2);

        mPresenter.submitFormReview();

        verify(mView, atLeastOnce()).setNumberOfDeliveryStatus(null);
        verify(mView, atLeastOnce()).setNumberOfMiscarriageStatus(null);
    }

    @Test
    public void shouldNotProceed_zipCodeGreaterThan12() {
        mPresenter.setZipCode("1234567890123");

        verify(mView).setZipCodeStatus(any(MinMaxValidation.class));
    }

    @Test
    public void shouldProceed_zipCodeLessThanOrEqual4() {
        mPresenter.setZipCode("1234");

        verify(mView, never()).setZipCodeStatus(any(MinMaxValidation.class));
    }
}
