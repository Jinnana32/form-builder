package com.itsgmobility.hrbenefits.presenters;

import com.itsgmobility.hrbenefits.common.item.CarBrandItem;
import com.itsgmobility.hrbenefits.domain.interactor.carlease.ValidateCarLeaseInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.device.GetChosenAccountNumberInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.device.GetChosenReleasingCenterInteractor;
import com.itsgmobility.hrbenefits.domain.interactor.device.GetMcInteractor;
import com.itsgmobility.hrbenefits.domain.model.CarBrand;
import com.itsgmobility.hrbenefits.domain.resp.ValidateCarLeaseResp;
import com.itsgmobility.hrbenefits.ui.benefits.benefits.BenefitsMvpView;
import com.itsgmobility.hrbenefits.ui.benefits.benefits.BenefitsPresenter;
import com.itsgmobility.hrbenefits.ui.benefits.carlease.CarLeaseActivity;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

public class BenefitsPresenterTest extends PresenterTest {

    @Mock
    ValidateCarLeaseInteractor mCarLeaseInteractor;

    @Mock
    GetMcInteractor mGetMcInteractor;

    @Mock
    GetChosenAccountNumberInteractor mGetChosenAccountNumberInteractor;

    @Mock
    GetChosenReleasingCenterInteractor mGetChosenReleasingCenterInteractor;

    @InjectMocks
    BenefitsPresenter mPresenter;

    @Mock
    BenefitsMvpView mView;

    @Before
    public void setUp() {
        mPresenter.attachView(mView);
    }

    @Test
    public void shouldProceedCarLease() {
        List<CarBrand> mockCarBrandList = new ArrayList<>();
        String mockSolId = "102";
        String mockSolRC = "102";
        String mockUnit = "Test";

        CarBrand mockCarBrands = CarBrand.builder()
                .id(1)
                .name("Toyota")
                .build();

        mockCarBrandList.add(mockCarBrands);

        CarBrandItem mockCarBrandItem = CarBrandItem.builder()
                .id(mockCarBrands.id())
                .carBrand(mockCarBrands.name())
                .build();

        ValidateCarLeaseResp mockCarLeaseResp = ValidateCarLeaseResp.builder()
                .isValid(true)
                .message("")
                .carBrand(mockCarBrandList)
                .unit(mockUnit)
                .solId(mockSolId)
                .solRC(mockSolRC)
                .build();

        List<CarBrandItem> mockCarBrandItemList = new ArrayList<>();
        mockCarBrandItemList.add(mockCarBrandItem);

        given(mCarLeaseInteractor.execute()).willReturn(Single.just(mockCarLeaseResp));

        mPresenter.validateCarLeaseRequest();
        verify(mView).showCarLease(mockCarBrandItemList, mockSolId, mockSolRC, mockUnit);
    }

    @Test
    public void shouldValidateCarLease() {
        mPresenter = spy(mPresenter);
        Class testClass = CarLeaseActivity.class;

        given(mGetMcInteractor.execute()).willReturn(Single.just(true));
        given(mGetChosenReleasingCenterInteractor.execute()).willReturn(Single.just("Test"));
        given(mGetChosenAccountNumberInteractor.execute()).willReturn(Single.just("109350022082"));

        mPresenter.onBenefitSelect(testClass);
        verify(mPresenter, atLeastOnce()).validateCarLeaseRequest();

    }
}
